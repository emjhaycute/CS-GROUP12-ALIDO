package com.example.finalproject;

import androidx.annotation.NonNull;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

    public class Register extends AppCompatActivity {
        EditText mUserName, mEmail, mPassword, mPhone;
        Button mRegisterBtn;
        TextView mLoginBtn;
        ProgressBar progressBar;
        FirebaseAuth authFireBase;


        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate (savedInstanceState);
            setContentView (R.layout.activity_register);
            mUserName = findViewById (R.id.inputUsername);
            mEmail = findViewById (R.id.inputEmail);
            mPassword = findViewById (R.id.inputPassword);
            mPhone = findViewById (R.id.inputPhone);
            mRegisterBtn = findViewById (R.id.btnregister);

            authFireBase = FirebaseAuth.getInstance ();
            progressBar = findViewById (R.id.progressBar);

            if(authFireBase.getCurrentUser () != null){
                startActivity (new Intent (getApplicationContext (),MainActivity.class));
                finish ();
            }

            mRegisterBtn.setOnClickListener (new View.OnClickListener () {
                @Override
                public void onClick(View view) {
                    String email = mEmail.getText ().toString ().trim ();
                    String password = mPassword.getText ().toString ().trim ();

                    if(TextUtils.isEmpty (email)){
                        mEmail.setError ("Email is Required.");
                        return;
                    }
                    if (TextUtils.isEmpty (password)){
                        mPassword.setError ("Password is Required.");
                        return;
                    }
                    if(password.length () < 6){
                        mPassword.setError ("Password must be [6] Characters.");
                        return;
                    }

                    progressBar.setVisibility (View.VISIBLE);


                    if(mPhone.getText().toString().isEmpty()){
                        Toast.makeText(Register.this, "Please enter a number", Toast.LENGTH_SHORT).show();
                    }else {
                        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                                "+63" + mPhone.getText().toString(), 60, TimeUnit.SECONDS,
                                Register.this,
                                new PhoneAuthProvider.OnVerificationStateChangedCallbacks(){
                                    @Override
                                    public void onVerificationCompleted(@NonNull PhoneAuthCredential phoneAuthCredential) {

                                    }

                                    @Override
                                    public void onVerificationFailed(@NonNull FirebaseException e) {
                                        Toast.makeText(Register.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                                    }

                                    @Override
                                    public void onCodeSent(@NonNull String verId, @NonNull PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                                        Intent intent  = new Intent(getApplicationContext(), verifyOTP.class);
                                        intent.putExtra("mUserName", mUserName.getText().toString());
                                        intent.putExtra("mEmail", mEmail.getText().toString());
                                        intent.putExtra("mPass", mPassword.getText().toString());
                                        intent.putExtra("mPhone", mPhone.getText().toString());
                                        intent.putExtra("verID", verId);
                                        startActivity(intent);
                                    }
                                }
                        );
                    }
                }

            });

        }

        public void clickEv(View view) {
            mPhone.setText("+63");
        }

        public void login(View view) {
            startActivity(new Intent(this, login.class));
        }
    }
