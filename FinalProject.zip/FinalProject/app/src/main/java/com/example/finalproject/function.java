package com.example.finalproject;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class function {
    public String saveToDB(String user_email, String user_Phone, String user_Name){
        DatabaseReference db_reLu = FirebaseDatabase.getInstance().getReference().child("USER");
        USER user = new USER(user_email, user_Phone, user_Name);
        try {
            db_reLu.push().setValue(user);
            return "DATA SAVED";
        }catch (Exception e){
            return "SUCCESS ON SAVING ACCOUNT INFORMATION";
        }
    }
}
